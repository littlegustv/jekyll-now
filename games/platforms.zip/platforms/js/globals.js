	var canvas = document.getElementById('mygame');
	var ctx = canvas.getContext("2d");

	var TILESIZE = 64,
		BUTTON_TIME = 300;
	var FPS = 60;
	var lw = 5;